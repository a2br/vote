//
//  ApprovalView.swift
//  playaround
//
//  Created by Anatole Debierre on 10/04/2022.
//

import SwiftUI


public struct ApprovalView: View {
        
    @Binding var candidates: [Candidate]
    // Receive number of voters from user code file main.swift
    @Binding var voters: [Voter]
    @State var tolerance: Double = 0.5
    
    let handleAppChange: (String, Opinion) -> Void
    let resetApp: () -> Void
    
    var board: Board {
        get {
            return Board(candidates: self.candidates, voters: self.voters)
        }
    }
    var election: ApprovalElection {
        get {
            return ApprovalElection(board: self.board, tolerance: self.tolerance)
        }
    }
    
    @State private var showRefreshSheet: Bool = false
    
    func handleChange(id: String, opinion: Opinion) -> Void {
        self.handleAppChange(id, opinion)
    }
    
    func reset() {
        self.resetApp()
    }
    
    public init(candidates: Binding<[Candidate]>, voters: Binding<[Voter]>, handleAppChange: @escaping (String, Opinion) -> Void, resetApp: @escaping () -> Void) {
        self._candidates = candidates
        self._voters = voters
        self.handleAppChange = handleAppChange
        self.resetApp = resetApp
    }
    
    @State private var isShowingSheet = false
    
    public var body: some View {
        VStack(alignment: .leading) {
            Text("Approval Voting")
                .font(.largeTitle)
                .bold()
            
            VStack {
           
                RenderedBoard(candidates: $candidates, voters: $voters, handleChange: handleChange, votingSystem: .approval($tolerance))
                HStack {
                    
                    let winner = self.election.leaderboard.first!.key
                    (
                        Text(winner.name).bold() + Text(" wins with \(self.election.leaderboard.first!.value) approvals!")
                    ).font(.title)

                    Spacer()
                    HStack {
                        Button(action: {
                            isShowingSheet.toggle()
                        }) { Image(systemName: "info.circle") }
                            .font(.title)
                            .padding(10)
                            .hoverEffect(.highlight)
                            .sheet(isPresented: $isShowingSheet) {
                                ScrollView(.vertical, showsIndicators: true) {
                                    VStack(alignment: .leading) {
                                        HStack {
                                            Text("Approval Voting")
                                                .font(.largeTitle)
                                                .bold()
                                                .padding(.vertical, 10)
                                            Spacer()
                                            Button(action: { isShowingSheet.toggle() }) {
                                                Text("Dismiss")
                                                    .font(.title)
                                            }
                                            .padding(10)
                                            .hoverEffect(.highlight)
                                        }
                                        
                                        Text("Procedure")
                                            .font(.title)
                                            .padding(.vertical, 10)
                                        Text("""
                                            Approval Voting is a subtype of scored voting systems: but instead of rating candidates from 1 to 5 for example, voters pick a 0 or a 1: they either like them or they don't. They write on their ballot the names of all the candidates they approve of. So far, so good! The winner has to be the one everybody likes the most.
                                            """)
                                        Text("Chicken dilemma")
                                            .font(.title)
                                            .padding(.vertical, 10)
                                        Text("""
                                            Well, not always. In addition to the fact that a "yes" or a "no" cannot exhaustively reflect our political preferences, voters that approve of all the candidates are encouraged to drop the ones they like the least to avoid dragging down their top choices. Similarly, voters that aren't satisfied with the political offer are incentivized to vote for the nearest candidate nonetheless.
                                            """)
                                        Spacer()
                                        Text("Overall Conclusion")
                                            .bold()
                                            .font(.largeTitle)
                                            .padding(.vertical, 10)
                                        Text("""
                                             I didn't cover all the existing voting systems --and the ones we don't talk about always seem the most interesting. I picked these three for the following reasons:
                                             
                                             1. Both the US and France use FPTP (with slight variations, France mixes that with Runoff systems, with 2 rounds, and the US... well, that would deserve a playground of its own);
                                             2. IRV is often called "Alternative Voting" (despite it not being the only alternative) and is used in some countries, including Australia. It would've seemed wrong not to mention it;
                                             3. I found Approval Voting interesting and a little counter-intuitive, even though it's proved to be of great performance.
                                             
                                             I encourage you to dig more into documentation about the Borda Count (a serious alternative to IRV) and the Concordet Method (that has the particularity to sometimes be infinitely recursive...).
                                             """)
                                        Text("I hope you learned something new today. Have a great day!")
                                            .bold()
                                            .padding(.vertical, 10)
                                        
                                    }
                                    .padding(50)
                                }
                                
                            }

                        Button(action: {
                            showRefreshSheet.toggle()
                            self.reset()
                        }) { Image(systemName: "arrow.clockwise") }
                            .padding(10)
                            .hoverEffect(.highlight)
                            .font(.title)

                    }
                }
                
                Spacer()
                let maxTolerance = 1.0
                HStack {
                    Slider(value: Binding(
                        get: { self.tolerance },
                        set: { (newValue) in
                            self.tolerance = newValue
                        }
                    ), in: 0.25...maxTolerance)
                    Text("Tolerance \(Int(self.tolerance / maxTolerance * 100))%").font(.title)
                }
            }
        }
        .padding(20)
        .navigationTitle(Text("Approval Voting"))
    
    }
}
