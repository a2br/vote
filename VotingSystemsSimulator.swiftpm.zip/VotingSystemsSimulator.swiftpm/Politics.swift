//
//  Politics.swift
//  playaround
//
//  Created by Anatole Debierre on 13/04/2022.
//

import Foundation

public typealias Opinion = (Double, Double)

public enum Entity {
    case candidate(Candidate)
    case voter(Voter)
}

public func randomOpinion() -> Opinion {
    let randomX = Double.random(in: -1...1)
    let randomY = Double.random(in: -1...1)
    return (randomX, randomY)
}


public func distance(lhs: Opinion, rhs: Opinion) -> Double {
    let (lx, ly) = lhs
    let (rx, ry) = rhs
    
    let xDist = lx - rx
    let yDist = ly - ry
    
    let dist = sqrt(pow(xDist, 2) + pow(yDist, 2))
    return dist
}

public func opinionStr(_ opinion: Opinion) -> String {
    let (x, y) = opinion
    let roundedX = round(x * 100) / 100.0
    let roundedY = round(y * 100) / 100.0
    let str = "(" + roundedX.description + ", " + roundedY.description + ")"
    return str
}
