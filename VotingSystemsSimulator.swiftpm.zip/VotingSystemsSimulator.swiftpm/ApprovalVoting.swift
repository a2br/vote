//
//  ApprovalVoting.swift
//  playaround
//
//  Created by Anatole Debierre on 13/04/2022.
//
// When each voter has a radius of approval
// Count: Whatever candidate wins the most approvals wins

public struct ApprovalElection {
    public let board: Board
    public let tolerance: Double
    public let approvals: [Voter:[Candidate:Bool]]
    public let leaderboard: [Dictionary<Candidate, Int>.Element]
    
    public init(board: Board, tolerance: Double = 0.5) {
        self.board = board
        self.tolerance = tolerance
        
        var approvals: [Voter:[Candidate:Bool]] = [:]
        for voter in board.voters {
            approvals[voter] = [:]
            for candidate in board.candidates {
                let dist = distance(lhs: voter.opinion, rhs: candidate.opinion)
                approvals[voter]![candidate] = dist < tolerance
            }
        }
        self.approvals = approvals
        
        var approvalCount: [Candidate:Int] = [:]
        for candidate in board.candidates {
            approvalCount[candidate] = 0
            for (_, list) in approvals {
                let hasSupport = list[candidate] == true
                if hasSupport {
                    approvalCount[candidate]! += 1
                }
            }
        }
        self.leaderboard = approvalCount.sorted { $0.value > $1.value }

    }
}
