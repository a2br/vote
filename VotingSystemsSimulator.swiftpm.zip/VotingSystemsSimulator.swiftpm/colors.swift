//
//  colors.swift
//  playaround
//
//  Created by Anatole Debierre on 16/04/2022.
//

import Foundation
import SwiftUI


public var colorNames: [Color:(String,[String])] {
    if #available(iOS 15.0, *) {
        return [
            .red: ("Red", ["Ronald", "Robert", "Raphael"]),
            .blue: ("Blue", ["Beatrice", "Bob", "Bella"]),
            .green: ("Green", ["Giovanni", "George", "Graham"]),
            .orange: ("Orange", ["Oscar", "Otto", "Octave"]),
            .indigo: ("Indigo", ["Indiana", "Isabelle", "Isaac"]),
            .mint: ("Mint", ["Maggie", "Mathilde", "Matthew"]),
            .pink: ("Pink", ["Patty", "Penelope", "Peter"]),
            .brown: ("Brown", ["Billy", "Ben", "Bjorn"]),
            .purple: ("Purple", ["Patricia", "Patrick", "Phoebe"]),
            .cyan: ("Cyan", ["Cindia", "Chloe", "Charlotte"]),
            .teal: ("Teal", ["Timothée", "Tanguy", "Thomas"])
        ]
    } else {
        return [
            .red: ("Red", ["Ronald", "Robert", "Raphael"]),
            .blue: ("Blue", ["Beatrice", "Bob", "Bella"]),
            .green: ("Green", ["Giovanni", "George", "Graham"]),
            .orange: ("Orange", ["Oscar", "Otto", "Octave"]),
            .pink: ("Pink", ["Patty", "Penelope", "Peter"]),
            .purple: ("Purple", ["Patricia", "Patrick", "Phoebe"])
        ]

    }
   
    
}

public let defaultColors: [Color] = Array(colorNames.keys)


public func getName(color: Color, number: Int) -> String {
    let (lastName, firstNames) = colorNames[color] ?? ("Null", ["Nondefined"])
    // Find last name
    let (q, r) = number.quotientAndRemainder(dividingBy: firstNames.count)
    let index = q > 0 ? r : number
    let firstName = firstNames[index]
    let suffix = q > 0 ? " " + q.description : ""
    let fullName = firstName + " " + lastName + suffix
    return fullName
}

// Credit: https://stackoverflow.com/questions/27342715/blend-uicolors-in-swift

public func addColor(_ color1: UIColor, with color2: UIColor) -> UIColor {
    var (r1, g1, b1, a1) = (CGFloat(0), CGFloat(0), CGFloat(0), CGFloat(0))
    var (r2, g2, b2, a2) = (CGFloat(0), CGFloat(0), CGFloat(0), CGFloat(0))

    color1.getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
    color2.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)

    // add the components, but don't let them go above 1.0
    return UIColor(red: min(r1 + r2, 1), green: min(g1 + g2, 1), blue: min(b1 + b2, 1), alpha: (a1 + a2) / 2)
}

public func multiplyColor(_ color: UIColor, by multiplier: CGFloat) -> UIColor {
    var (r, g, b, a) = (CGFloat(0), CGFloat(0), CGFloat(0), CGFloat(0))
    color.getRed(&r, green: &g, blue: &b, alpha: &a)
    return UIColor(red: r * multiplier, green: g * multiplier, blue: b * multiplier, alpha: a)
}

public func +(color1: UIColor, color2: UIColor) -> UIColor {
    return addColor(color1, with: color2)
}

public func *(color: UIColor, multiplier: Double) -> UIColor {
    return multiplyColor(color, by: CGFloat(multiplier))
}



public func computeColor(candidates: [Candidate]) -> Color {
    if candidates.count < 1 { return .black }
    let unit = CGFloat(Double(1) / Double(candidates.count))
    var sum: UIColor = .black
    for c in candidates {
        sum = addColor(sum, with: multiplyColor(UIColor(c.color), by: unit))
    }
    return Color(sum)
}
