//
//  Candidate.swift
//  playaround
//
//  Created by Anatole Debierre on 11/04/2022.
//

import SwiftUI

// A Candidate is basically a fancy tuple with a geometrical shape

public struct Candidate: Hashable {
    // Make it uniquely identifiable
    public let id: String
    // What name to display
    public var name: String
    // Coordinates
    public var opinion: Opinion
    public let color: Color
    
    public init(x: Double, y: Double, color: Color = .blue, name: String, forcedId: String? = nil) {
        self.opinion = (x, y)
        self.color = color
        self.name = name
        self.id = forcedId ?? UUID().uuidString
    }
    
    // Make is hashable
    public static func == (lhs: Self, rhs: Self) -> Bool {
        return lhs.id == rhs.id
    }
    
    public func hash(into hasher: inout Hasher) {
        hasher.combine(self.id)
    }
    
    public static func genRand(n: Int = 1, colors: [Color] = defaultColors) -> [Self] {
        var final: [Self] = []
        for i in 0..<n {
            let (x, y) = randomOpinion()
            let c = i < colors.count ? i : i % colors.count
            let color = colors[c]
            let (passes, _) = i.quotientAndRemainder(dividingBy: colors.count)
            let name = getName(color: color, number: passes)
            final += [Self(x: x, y: y, color: colors[c], name: name)]
        }
        return final
    }
}
