//
//  IRVView.swift
//  playaround
//
//  Created by Anatole Debierre on 17/04/2022.
//

import SwiftUI


public struct IRVView: View {
        
    @Binding var candidates: [Candidate]
    // Receive number of voters from user code file main.swift
    @Binding var voters: [Voter]
    let handleAppChange: (String, Opinion) -> Void
    let resetApp: () -> Void
    
    
    @State var round: Float = 0

    @State private var showRefreshSheet: Bool = false

    func handleChange(id: String, opinion: Opinion) -> Void {
        //MARK: Call parent
        self.handleAppChange(id, opinion)
        
        // Update election with new board
        let newBoard = Board(candidates: self.candidates, voters: self.voters)
        
        let election = InstantRunoffElection(board: newBoard)

        // Set round if reduced
        self.round = min(Float(election.rounds.count - 1), self.round)
    }
    
    func reset() {
        self.resetApp()
    }
    
    public init(candidates: Binding<[Candidate]>, voters: Binding<[Voter]>, handleAppChange: @escaping (String, Opinion) -> Void, resetApp: @escaping () -> Void) {
        self.handleAppChange = handleAppChange
        self.resetApp = resetApp
        self._candidates = candidates
        self._voters = voters
    }
        
    @State private var isShowingSheet = false
    
    public var body: some View {
        VStack(alignment: .leading) {
            let board = Board(candidates: self.candidates, voters: self.voters)
            let election = InstantRunoffElection(board: board)
            let i = min(Float(election.rounds.count - 1), self.round)
            //FIXME
            let currentRound = election.rounds[Int(i)]
            let lastRound = election.rounds.last!
            
            Text("Instant Runoff Voting")
                .font(.largeTitle)
                .bold()
            
            VStack {
                
                RenderedBoard(candidates: Binding(get: { currentRound.election.board.candidates }, set: { _, _ in }), voters: self.$voters, handleChange: handleChange, votingSystem: .irv)
                
                        HStack {
                            
                            if Int(i) == election.rounds.count - 1 {
                                if let winner = lastRound.pickedWinner {
                                    (Text(winner.name).bold() + Text(String(format: " wins with %.0f", currentRound.election.getPercentage(candidate: winner) ?? 0) + " % of final votes!")).font(.title)
                                } else {
                                    Text("It's a tie!").font(.title)
                                }
                            } else {
                                let eliminated = currentRound.roundLoser
                                (Text(eliminated.name).bold() + Text(" is eliminated.")).font(.title)
                            }
                   
                            Spacer()
                            HStack {
                                Button(action: {
                                    isShowingSheet.toggle()
                                }) { Image(systemName: "info.circle") }
                                    .font(.title)
                                    .padding(10)
                                    .hoverEffect(.highlight)
                                    .sheet(isPresented: $isShowingSheet) {
                                        ScrollView(.vertical, showsIndicators: true) {
                                            VStack(alignment: .leading) {
                                                HStack {
                                                    Text("Instant Runoff Voting")
                                                        .font(.largeTitle)
                                                        .bold()
                                                    Spacer()
                                                    Button(action: { isShowingSheet.toggle() }) {
                                                        Text("Dismiss")
                                                            .font(.title)
                                                    }
                                                    .padding(10)
                                                    .hoverEffect(.highlight)
                                                }
                                                Text("Procedure")
                                                    .font(.title)
                                                    .padding(.vertical, 10)
                                                Text("""
                                                    IRV is a kind of ranked voting system: voters provide not one, but all candidates' names, ranked in order of preference (another ranked voting system is the Borda count, a very cool nerdy system we won't talk about here). An runoff system is a series of elections, each one narrowing the list of candidates until a winner is found --if at any point a candidate score > 50%, they win. But with IRV, the voter only casts 1 ballot, and at each round, the highest-placed still-eligible candidate on each ranked list is the one that's counted: in short, it's like the FPTP election, except that if your favorite candidate did poorly with other voters, your ballot has fallbacks!
                                                    """)
                                                Text("Center squeeze")
                                                    .font(.title)
                                                    .padding(.vertical, 10)
                                                Text("""
                                                    When you have 3 candidates that form a line on the political compass, the one in the middle gets eliminated, and the final winner is declared after the next round. The loser's side is unhappy, the opposite side won... but they could've made that failure less harsh. Can you guess what strategy they could've adopted?
                                                    
                                                    They could've massively voted for the center candidate. It would've eliminated their own candidate at round 1, yes, but they would have crushed the opposide side at round 2. It's called the "center squeeze".
                                                    """)
                                                Spacer()
                                                
                                            }
                                            .padding(50)
                                        }
                                    }

                                Button(action: {
                                    showRefreshSheet.toggle()
                                    self.reset()
                                }) { Image(systemName: "arrow.clockwise") }
                                    .padding(10)
                                    .hoverEffect(.highlight)
                                    .font(.title)

                            }
                        }
                        Spacer()
                        HStack {
                            let disabled = election.rounds.count < 2
                            Slider(value: !disabled ? Binding(
                                get: { self.round },
                                set: { (newValue) in
                                    self.round = newValue
                                }
                            ) : Binding(
                                get: { Float(1.0) },
                                set: { _,_ in  }
                            ), in: 0.0...max(1.0, Float(election.rounds.count - 1)), step: 1)
                                .disabled(disabled)
                            
                            Text("Round \(Int(i + 1))").font(.title)
                        }
            }
                            
        }
        .padding(20)

    }
}
