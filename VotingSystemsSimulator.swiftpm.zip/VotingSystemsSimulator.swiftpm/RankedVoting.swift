//
//  RankedVoting.swift
//  playaround
//
//  Created by Anatole Debierre on 13/04/2022.
//

// Each voter ranks every candidate from farest to nearest
// Count: - IRV / - Borda count: add up ranks, one with lowest wins / - Condorcet method: nerd thing

public struct RankedElection {
    public let board: Board
    public let ballots: [Voter:[Candidate]]
    
    public init(board: Board) {
        self.board = board
        
        var ballots: [Voter:[Candidate]] = [:]
        for voter in board.voters {
            let list = getList(voter: voter, candidates: board.candidates)
            ballots[voter] = list
        }
        
        self.ballots = ballots
    }
    
    public func instantRunoff() -> InstantRunoffElection {
        return InstantRunoffElection(board: board)
    }
    
    public func bordaCount() -> BordaCountElection {
        return BordaCountElection(board: board, ballots: ballots)
    }
}


public struct BordaCountElection {
    public let board: Board
    public let ballots: [Voter:[Candidate]]
    public let leaderboard: [Dictionary<Candidate, Int>.Element]
    
    public init(board: Board, ballots: [Voter:[Candidate]]? = nil) {
        let ballots = ballots ?? getBallots(board: board)
        self.board = board
        self.ballots = ballots
        
        // For each candidate: add up their ranks
        // Set initial values
        var rankCount: [Candidate:Int] = [:]
        for candidate in board.candidates {
            rankCount[candidate] = 0
        }
        // Count
        for (_, ballot) in ballots {
            for (i, choice) in ballot.enumerated() {
                rankCount[choice]! += (i + 1)
            }
        }
        let leaderboard = rankCount.sorted { $0.value < $1.value }
        self.leaderboard = leaderboard
    }
}

public func getBallots(board: Board) -> [Voter:[Candidate]] {
    var ballots: [Voter:[Candidate]] = [:]
    for voter in board.voters {
        let list = getList(voter: voter, candidates: board.candidates)
        ballots[voter] = list
    }
    return ballots
}


public func getList(voter: Voter, candidates: [Candidate]) -> [Candidate] {
    // Sort candidates in function of the dist from the voter
    return candidates.sorted { a, b in
        let distA = distance(lhs: voter.opinion, rhs: a.opinion)
        let distB = distance(lhs: voter.opinion, rhs: b.opinion)
        
        return distA < distB
    }
}
