//
//  InstantRunoff.swift
//  playaround
//
//  Created by Anatole Debierre on 17/04/2022.
//


public struct InstantRunoffElection {
    public let board: Board
    public let rounds: [IRVRound]
    
    public init(board: Board) {
        self.board = board        
        
        // Spin up election and store result
        var rounds: [IRVRound] = []
        var remainingCandidates: [Candidate] = board.candidates
        while remainingCandidates.count >= 2 {
            // Spin up round
            let roundBoard = Board(candidates: remainingCandidates, voters: board.voters)
            let round = IRVRound(board: roundBoard)
            rounds.append(round)
            // If winner is determined, break the loop
            if round.pickedWinner != nil {
                
                break
            }
            // No winner is determined (and there's more than 2 candidates left, without abstention)
            if let index = remainingCandidates.firstIndex(of: round.roundLoser) {
                remainingCandidates.remove(at: index)
            }
        }
        
        self.rounds = rounds
    }
    
    public var lastRound: IRVRound {
        get {
            return self.rounds.last!
        }
    }
}

public struct IRVRound {
    public let board: Board
    public let election: FPTPElection
    
    public let roundLoser: Candidate
    public let pickedWinner: Candidate?
    public init(board: Board) {
        let election = FPTPElection(board: board)

        self.board = board
        self.election = election
        
        // There should be 1st and last items, otherwise something's wrong
        let (lastOne, _) = election.voteCount.last!
        self.roundLoser = lastOne
        
        let (numberOne, biggestScore) = election.voteCount.first!
        // As long as everybody's voting (it's the case in IRV)
        if Double(biggestScore) / Double(board.voters.count) > 0.5 {
            // numberOne is the winner
            self.pickedWinner = numberOne
        } else {
            self.pickedWinner = nil
        }
    }
}
