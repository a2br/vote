//
//  AppView.swift
//  playaround
//
//  Created by Anatole Debierre on 18/04/2022.
//

import SwiftUI


// Will be placed in main.swift
public func generateBoardWithInstructions(c: Int, v: Int) -> Board {
    return Board(candidates: Candidate.genRand(n: c), voters: Voter.genRand(n: v))
}


public struct AppView: View {
    @State public var selectedTab: Int = 0
    
    @State var candidates: [Candidate] = Candidate.genRand(n: 5)
    @State var voters: [Voter] = Voter.genRand(n: 150)
    @State var frame = 1
    
    public init(board: Board? = nil, tab: Int? = nil) {
        if let board = board {
            // Set board
            self._candidates = State(initialValue: board.candidates)
            self._voters = State(initialValue: board.voters)
            // Select voting system
        }
        if let tab = tab {
            self._selectedTab = State(initialValue: tab)
        }
    }
    
    public func handleChange(id: String, opinion: Opinion) {
        // Update candidates and voters
        let (newCandidates, newVoters) = obeyUpdateOrder(id: id, opinion: opinion, candidates: self.$candidates, voters: self.$voters)
        self.candidates = []
        self.voters = []
        self.candidates.append(contentsOf: newCandidates)
        self.voters.append(contentsOf: newVoters)
        frame += 1
    }
    
    public func reset() {
        let board = generateBoardWithInstructions(c: self.candidates.count, v: self.voters.count)
        self.candidates = []
        self.voters = []
        self.candidates.append(contentsOf: board.candidates)
        self.voters.append(contentsOf: board.voters)
    }
    
    public func setCandidateCount() {
        
    }
    
    public func setVotersCount() {
        
    }
    
    @State private var welcomeSheetVisible = true
    
    public var body: some View {
        Button(action: {}) {}
            .frame(height: 0)
            .sheet(isPresented: $welcomeSheetVisible) {
                VStack(alignment: .center) {
                    Spacer()
                    Image(systemName: "hand.wave")
                        .font(.system(size: 150))
                        .foregroundColor(.accentColor)
                        .padding(30)
                    Text("Welcome!")
                        .font(.system(size: 40))
                        .bold()
                        .padding(30)
                    (
                        Text("This app models presidential elections & allows you to compare results in function of the voting system. The big board in the middle is the ") + Text("political compass").bold() + Text(": the 2 dimensions could mean \"Left v. Right\" & \"Authoritarian v. Liberal\", for instance. Small dots are voters, big squares are candidates; you can drag them, or press & hold for more information. Buttons in the bottom right allow you to reset the plane or learn more about a voting system.")
                    )
                        .font(.system(size: 24))
                        .multilineTextAlignment(.center)
                    Spacer()
                    HStack {
                        Spacer()
                        Button(action: { welcomeSheetVisible.toggle() }) {
                            Text("Enjoy")
                                .font(.title)
                        }
                        .padding(10)
                        .hoverEffect(.highlight)
                    }
                }
                .padding(50)
            }
        TabView(selection: $selectedTab) {
                let _ = self.frame
                FPTPView(candidates: self.$candidates, voters: self.$voters, handleAppChange: handleChange, resetApp: reset)
                    .tabItem {
                        Label("FPTP", systemImage: "person")
                    }
                    .tag(0)

                IRVView(candidates: self.$candidates, voters: self.$voters, handleAppChange: handleChange, resetApp: reset)
                    .tabItem {
                        Label("Instant Runoff", systemImage: "list.number")
                    }
                    .tag(1)

                ApprovalView(candidates: self.$candidates, voters: self.$voters, handleAppChange: handleChange, resetApp: reset)
                    .tabItem {
                        Label("Approval", systemImage: "checklist")
                    }
                    .tag(2)

            }
        }
}
