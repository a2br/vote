//
//  Board.swift
//  playaround
//
//  Created by Anatole Debierre on 11/04/2022.
//

// A board is a system of candidates and voters

public struct Board {
    // Lists of Candidates and Voters
    public var candidates: [Candidate] = []
    public var voters: [Voter] = []
    
    public init(candidates: [Candidate], voters: [Voter]) {
        self.voters = voters
        self.candidates = candidates
    }
    
    public static func genRand(candidates: Int, voters: Int) -> Board {
        let c: [Candidate] = Candidate.genRand(n: candidates)
        let v: [Voter] = Voter.genRand(n: voters)
        return Board(candidates: c, voters: v)
    }
}
