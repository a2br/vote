//
//  FPPVoterDot.swift
//  playaround
//
//  Created by Anatole Debierre on 14/04/2022.
//

import SwiftUI

public struct FPPVoterDot: View {
    let ratio: CGFloat = 0.05
    let id: String
    let color: Color?
    let opinion: Opinion
    let size: Double

    public var body: some View {
        Circle()
            .fill((color ?? .black).opacity(0.5))
            .frame(width: size, height: size)
            .contextMenu {
                Text((color != nil ? "Voter" : "Absentionist") + " " + opinionStr(opinion))

                //TODO: Print more information or make sheet
//                Button {
//                    print("More information about Voter")
//                } label: {
//                    Label("More information", systemImage: "info.circle")
//                }
            }
            .contentShape(Circle())
            .hoverEffect(.lift)
    }
    
    public init(voter: Voter, side: Double, color: Color? = nil) {
        self.id = voter.id
        self.color = color
        self.opinion = voter.opinion
        self.size = side * ratio
    }
    
}
