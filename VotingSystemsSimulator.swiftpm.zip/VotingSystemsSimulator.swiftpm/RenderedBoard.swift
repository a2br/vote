//
//  RenderedBoard.swift
//  playaround
//
//  Created by Anatole Debierre on 10/04/2022.
//

import SwiftUI


extension Color {
  init(_ hex: UInt, alpha: Double = 1) {
    self.init(
      .sRGB,
      red: Double((hex >> 16) & 0xFF) / 255,
      green: Double((hex >> 8) & 0xFF) / 255,
      blue: Double(hex & 0xFF) / 255,
      opacity: alpha
    )
  }
}


let BOX_MARGIN: Double = 15
public var SIDE_PX: Double = 340
public var HALF_SIDE: Double {
    get {
        return Double(SIDE_PX / 2) - (BOX_MARGIN)
    }
}

func renderOpinion(zero: CGPoint, opinion: Opinion) -> CGPoint {
    let (x, y) = opinion
    
    // Top right is (1, 1), bottom left is (-1, -1)
    let xPos = zero.x + x * HALF_SIDE
    let yPos = zero.y - y * HALF_SIDE
    
    return CGPoint(x: xPos, y: yPos)
}

func findOpinion(zero: CGPoint, pos: CGPoint) -> Opinion {
    let xPos = pos.x
    let yPos = pos.y
    
    let x = (xPos - zero.x) / HALF_SIDE
    let y = -(yPos - zero.y) / HALF_SIDE
    
    return (x, y)
}

func obeyUpdateOrder(id: String, opinion: Opinion, candidates: Binding<[Candidate]>, voters: Binding<[Voter]>) -> ([Candidate], [Voter]) {
    // Search in candidates
    var finalCandidates: [Candidate] = []
    var found: Bool = false
    for c in candidates {
        if c.wrappedValue.id == id {
            let newCand = Candidate(x: opinion.0, y: opinion.1, color: c.wrappedValue.color, name: c.wrappedValue.name,forcedId: id)
            finalCandidates += [newCand]
            found = true
        } else { finalCandidates += [c.wrappedValue] }
    }
    if found {
        return (finalCandidates, voters.wrappedValue)
    } else {
        // Search in voters
        var finalVoters: [Voter] = []
        for v in voters {
            if v.wrappedValue.id == id {
                let newVoter = Voter(x: opinion.0, y: opinion.1, forcedId: id)
                finalVoters += [newVoter]
            } else { finalVoters += [v.wrappedValue] }
        }
        return (candidates.wrappedValue, finalVoters)
    }
    
}

public enum VotingSystem {
    case fptp
    case irv
    case approval(Binding<Double>? = nil)
}

public struct RenderedBoard: View {
    
    @Binding var candidates: [Candidate]
    @Binding var voters: [Voter]
    
    let handleChange: (String, Opinion) -> Void
    let votingSystem: VotingSystem
    @State private var frame = 1
    
    func handleSystemChange(id: String, opinion: Opinion) -> Void {
        self.frame += 1
        
        // Notify hierarchy
        handleChange(id, opinion)
    }
    
    
    func movePoint(id: String, zero: CGPoint) -> (DragGesture.Value) -> Void {
        let move = {
            (info: DragGesture.Value) -> Void in
            let loc = info.location
            var (x, y) = findOpinion(zero: zero, pos: loc)
            
            if x > 1 { x = 1 }
            if y > 1 { y = 1 }
            if x < -1 { x = -1 }
            if y < -1 { y = -1 }

            self.handleSystemChange(id: id, opinion: (x, y))
            
        }
        
        return move
    }
    
    public init(candidates: Binding<[Candidate]>, voters: Binding<[Voter]>, handleChange: @escaping (String, Opinion) -> Void, votingSystem: VotingSystem) {
        self._candidates = candidates
        self._voters = voters
        self.handleChange = handleChange
        self.votingSystem = votingSystem
    }
    
    public var body: some View {
        GeometryReader { geoA in
            let dim = min(geoA.size.width, geoA.size.height)
            let _ = (SIDE_PX = Double(dim))

            GeometryReader { geo in
                        let frame = geo.frame(in: .local)
                        let zero = CGPoint(x: frame.midX, y: frame.midY)
                        let frameG = geo.frame(in: .global)
                        let zeroG = CGPoint(x: frameG.midX, y: frameG.midY)


                        // Board background
                        if #available(iOS 15.0, *) {
                            RoundedRectangle(cornerRadius: 16)
                                .fill(.thickMaterial)
                        } else {
                            // Fallback on earlier versions
                            Rectangle()
                                .fill(.gray)
                        }


                        let board = Board(candidates: self.candidates, voters: self.voters)

                        switch self.votingSystem {
                        case .fptp:
                            let election = FPTPElection(board: board)

                            // Place voters
                            ForEach(voters, id: \.self) { v in
                                // Figure out position
                                let pos = renderOpinion(zero: zero, opinion: v.opinion)
                                // Figure out nearest FPTP candidate -> color
                                let c = election.getVote(voter: v)
                                FPPVoterDot(voter: v, side: Double(dim), color: c?.color)
                                    .position(pos)
                                    .gesture(
                                        DragGesture(coordinateSpace: .global)
                                            .onChanged(movePoint(id: v.id, zero: zeroG))
                                    )
                            }

                            // Place candidates
                            ForEach(candidates, id: \.self) { c in
                                // Figure out position
                                let pos = renderOpinion(zero: zero, opinion: c.opinion)


                                CandidateDot(candidate: c, side: Double(dim))
                                    .position(pos)
                                    .gesture(
                                        DragGesture(coordinateSpace: .global)
                                            .onChanged(movePoint(id: c.id, zero: zeroG))
                                    )
                            }
                        case .irv:
                            let election = FPTPElection(board: board)

                            // Place voters
                            ForEach(voters, id: \.self) { v in
                                // Figure out position
                                let pos = renderOpinion(zero: zero, opinion: v.opinion)
                                // Figure out nearest FPTP candidate -> color
                                let c = election.getVote(voter: v)
                                FPPVoterDot(voter: v, side: Double(dim), color: c?.color)
                                    .position(pos)
                                    .gesture(
                                        DragGesture(coordinateSpace: .global)
                                            .onChanged(movePoint(id: v.id, zero: zeroG))
                                    )
                            }

                            // Place candidates
                            ForEach(candidates, id: \.self) { c in
                                // Figure out position
                                let pos = renderOpinion(zero: zero, opinion: c.opinion)


                                CandidateDot(candidate: c, side: Double(dim))
                                    .position(pos)
                                    .gesture(
                                        DragGesture(coordinateSpace: .global)
                                            .onChanged(movePoint(id: c.id, zero: zeroG))
                                    )
                            }
                        case .approval(let tolerance):
                            // Set approval voting election instance
                            let election = ApprovalElection(board: board, tolerance: tolerance?.wrappedValue ?? 0.5)
                            // Draw entities & makeup accordingly
                            ForEach(voters, id: \.self) { v in
                                // Figure out position
                                let pos = renderOpinion(zero: zero, opinion: v.opinion)
                                // Figure out nearest FPTP candidate -> color
                                let choices = Array(election.approvals[v]!.keys).filter { election.approvals[v]![$0] == true }

                                // Compute color
                                let color: Color = computeColor(candidates: choices)

                                FPPVoterDot(voter: v, side: Double(dim), color: color)
                                    .position(pos)
                                    .gesture(
                                        DragGesture(coordinateSpace: .global)
                                            .onChanged(movePoint(id: v.id, zero: zeroG))
                                    )
                            }

                            // Place candidates
                            ForEach(candidates, id: \.self) { c in
                                // Figure out position
                                let pos = renderOpinion(zero: zero, opinion: c.opinion)
                                // So that voters are included when their centers are
                                let WEIRD_OFFSET = 28
                                let DIAMETER = CGFloat( max(Float(0.0), Float(SIDE_PX) * Float(election.tolerance)) - Float(WEIRD_OFFSET) )
                                Circle()
                                    .strokeBorder(c.color.opacity(0.4), lineWidth: 3)
                                    .background(Color.black.opacity(0))
                                    .frame(width: DIAMETER, height: DIAMETER)
                                    .position(pos)
                                    .clipped()
                                    .zIndex(1)
                                CandidateDot(candidate: c, side: Double(dim))
                                    .position(pos)
                                    .gesture(
                                        DragGesture(coordinateSpace: .global)
                                            .onChanged(movePoint(id: c.id, zero: zeroG))
                                    )
                                    .zIndex(2)
                            }
                        }

                    }
                    .frame(width: CGFloat(SIDE_PX), height: CGFloat(SIDE_PX))

        }

    }
    
}
