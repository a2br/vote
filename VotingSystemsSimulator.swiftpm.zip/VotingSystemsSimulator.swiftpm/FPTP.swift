//
//  FPTP.swift
//  playaround
//
//  Created by Anatole Debierre on 13/04/2022.
//

// Functions related to FPP

// Visualization : 1 voter, then multiple to show flaws

public struct FPTPElection {
    public let board: Board
    
    public let voteCount: [(Candidate, Int)]
    public let voteSheet: [Voter:Candidate]
    
    public init(board: Board) {
        self.board = board
        var voteCount: [Candidate:Int] = [:]
        var voteSheet: [Voter:Candidate] = [:]
        
        // Initialize values
        for c in board.candidates {
            voteCount[c] = 0
        }
        // Run through each voter
        for v in board.voters {
            // For each candidate: Determine distance => set relationships to render
            // Sum votes in Dictionnary with Candidates as keys
            var (winner, winnerDist): (Candidate?, Double) = (nil, 3 /* Because 3 > sqrt(8) */)
            for c in board.candidates {
                // Determine distance & satisfaction
                let dist = distance(lhs: v.opinion, rhs: c.opinion)
                if dist < winnerDist {
                    (winner, winnerDist) = (c, dist)
                }
            }
            if let choice = winner {
                voteCount[choice]! += 1
                voteSheet[v] = choice
            }
        }
        
        self.voteCount = voteCount.sorted(by: { a, b in
            a.value > b.value
        })
        self.voteSheet = voteSheet
                    
        // Set leaderboard of sorted candidates with number of votes
    }
    
    public func getScore(candidate: Candidate) -> Int? {
        for (cand, score) in self.voteCount {
            if cand == candidate {
                return score
            }
        }
        return nil
    }
    
    public func getPercentage(candidate: Candidate) -> Double? {
        let score = self.getScore(candidate: candidate)
        if let score = score {
            let percentage = (Double(score) / Double(self.voteSheet.count)) * 100
            return percentage
        }
        return nil
    }
    
    public func getVote(voter: Voter) -> Candidate? {
        return self.voteSheet[voter] ?? nil
    }
    
}
