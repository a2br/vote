//
//  CandidateDot.swift
//  playaround
//
//  Created by Anatole Debierre on 14/04/2022.
//

import SwiftUI

public struct CandidateDot: View {
    let ratio: CGFloat = 0.08
    let color: Color
    let name: String
    let opinion: Opinion
    let size: Double
    
    let id: String
    

    public var body: some View {
        RoundedRectangle(cornerRadius: size * 0.3)
            .fill(color)
            .frame(width: size, height: size)
            .shadow(color: .black.opacity(0.4), radius: 8, x: 2, y: 2)
            .contentShape(RoundedRectangle(cornerRadius: SIDE_PX * ratio * 0.3, style: .continuous))
            .hoverEffect(.lift)
            .contextMenu {
                Text(name + " " + opinionStr(opinion) )
                
//                Button {
//                    print("More information about Candidate")
//                } label: {
//                    Label("More information", systemImage: "info.circle")
//                }
            }
    }
    
    public init(candidate: Candidate, side: Double) {
        self.id = candidate.id
        self.color = candidate.color
        self.name = candidate.name
        self.opinion = candidate.opinion
        self.size = side * ratio
    }
    
    
}
