//
//  FPTPView.swift
//  playaround
//
//  Created by Anatole Debierre on 10/04/2022.
//

import SwiftUI

public struct FPTPView: View {
    
    @Binding var candidates: [Candidate]
    // Receive number of voters from user code file main.swift
    @Binding var voters: [Voter]
    
    let handleAppChange: (String, Opinion) -> Void
    let resetApp: () -> Void
    
    var board: Board {
        get {
            return Board(candidates: self.candidates, voters: self.voters)
        }
    }
    var election: FPTPElection {
        get {
            return FPTPElection(board: self.board)
        }
    }
    
    @State private var showSpreadSheet: Bool = false
    @State private var showRefreshSheet: Bool = false
    
    func handleChange(id: String, opinion: Opinion) -> Void {
        self.handleAppChange(id, opinion)
    }
    
    func reset() {
        self.resetApp()
    }
    
    public init(candidates: Binding<[Candidate]>, voters: Binding<[Voter]>, handleAppChange: @escaping (String, Opinion) -> Void, resetApp: @escaping () -> Void) {
        self._candidates = candidates
        self._voters = voters
        self.handleAppChange = handleAppChange
        self.resetApp = resetApp
    }
    
    @State private var isShowingSheet = false
    
    public var body: some View {
        VStack(alignment: .leading) {
                Text("FPTP Voting")
                    .font(.largeTitle)
                    .bold()
            
                VStack {
                    RenderedBoard(candidates: $candidates, voters: $voters, handleChange: handleChange, votingSystem: .fptp)
                    HStack {
                        
                        let winnerName = self.election.voteCount.first!.0.name
                        let tie = self.election.voteCount.count > 1 && self.election.voteCount[0].1 == self.election.voteCount[1].1
                        (!tie ? (
                            Text(winnerName).bold() + Text(" wins!")
                        ) : (Text("It's a tie!"))
                        )
                        .font(.title)
                        Spacer()
                        HStack {
                            Button(action: {
                                isShowingSheet.toggle()
                            }) { Image(systemName: "info.circle") }
                                .font(.title)
                                .padding(10)
                                .hoverEffect(.highlight)
                                .sheet(isPresented: $isShowingSheet) {
                                    ScrollView(.vertical, showsIndicators: true) {
                                        VStack(alignment: .leading) {
                                            HStack {
                                                Text("Plurality Voting")
                                                    .font(.largeTitle)
                                                    .bold()
                                                Spacer()
                                                Button(action: { isShowingSheet.toggle() }) {
                                                    Text("Dismiss")
                                                        .font(.title)
                                                }
                                                .padding(10)
                                                .hoverEffect(.highlight)
                                            }
                                            .padding(.vertical, 10)
                                            Text("Procedure")
                                                .font(.title)
                                                .padding(.vertical, 10)
                                            Text("""
                                                Every voter picks its favorite candidate. The one with the most votes wins the election. It is used in most democratic countries for its simplicity and transparency. As an obscure reference to horse racing, it's often referred to as "First Past The Post" voting.
                                                """)
                                            Text("Spoiler effect")
                                                .font(.title)
                                                .padding(.vertical, 10)
                                            Text("""
                                                It comes with one downside, though: when multiple candidates have approximately the same ideas, they end up stealing each other's votes, resulting in the other side's victory. Consequently, voters are incentivized to vote for the candidate they like that's the most popular: it's the "tactical vote" ("vote utile"). This can easily be observed during the ongoing French presidential election: while this used to be more frequent on the left, the far right had its votes fragmented with the entry of E. Zemmour, who seduced some of M. Le Pen's electors.
                                                """)
                                            Text("Consequences")
                                                .font(.title)
                                                .padding(.vertical, 10)
                                            Text("""
                                                This social dynamic often leads to bipartisan systems that polarize the political compass: a great example is the United States, where Democrats face Republicans, despite some minor "third parties".
                                                """)
                                            Spacer()
                                            
                                        }
                                        .padding(50)
                                    }
                                }

                            Button(action: {
                                showRefreshSheet.toggle()
                                self.reset()
                            }) { Image(systemName: "arrow.clockwise") }
                                .padding(10)
                                .hoverEffect(.highlight)
                                .font(.title)

                        }
                    }
                    Spacer()

                }
           
                
                
            }
            .padding(20)
            .navigationTitle(Text("FPTP Election"))
        
    }
}
