//
//  Voter.swift
//  playaround
//
//  Created by Anatole Debierre on 11/04/2022.
//

import Foundation

// A Voter is basically a fancy tuple

public struct Voter: Hashable {
    // Make it uniquely identifiable
    public let id: String
    // Coordinates
    public var opinion: Opinion
    
    public init(x: Double, y: Double, forcedId: String? = nil) {
        self.opinion = (x, y)
        self.id = forcedId ?? UUID().uuidString
    }
    
    // Make is hashable
    public static func == (lhs: Self, rhs: Self) -> Bool {
        return lhs.id == rhs.id
    }
    
    public func hash(into hasher: inout Hasher) {
        hasher.combine(self.id)
    }
    
    public static func genRand(n: Int = 1) -> [Self] {
        var final: [Self] = []
        for _ in 1...n {
            let (x, y) = randomOpinion()
            final += [Self(x: x, y: y)]
        }
        return final
    }

}
